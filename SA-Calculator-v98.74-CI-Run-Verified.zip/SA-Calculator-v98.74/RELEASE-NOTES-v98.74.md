# SA Calculator v98.74 — Finance calculator reference correction

## Reference basis
This release uses the user's supplied GST, Saving, Percentage and Tip screenshots, plus the supplied Loan Calculator video/contact sheet, as the primary UI reference. The screenshot capture is 709 × 1536 px; at the app's approximate 2× density, the common field card is about 330 × 88 logical px.

## UI corrections
- Unified GST, Saving, Tip, Percentage, Discount, Salary and SIP editable fields to the Loan field-card family.
- Standard card: 88px minimum height, 2px border, 22px radius, 12px inset, 50px icon tile, 12px icon/text gap.
- Compact widths (≤380px): 82px minimum height, 48px icon tile and 10px content gap.
- Label/value hierarchy is vertical: 15px label above a 22px value/placeholder.
- Reference coral corrected to `#FE6F61`; pale icon tile is `#FFE5E4`; page background is `#F4F5F7`; card surface is white in light mode.
- GST: Original Amount and GST Rate are separate Loan-sized cards; 5%/18% quick rates remain in the rate card; With/Without GST and Same/Different State controls remain compact pills outside the cards.
- Percentage: removed the alternate Percent Change mode from this reference screen and removed prefilled demo values; only Original Amount and Percentage(%) are shown.
- Saving: only Saving Amount, Interest Rate(%) and Saving Period are visible as requested by the reference; the numeric period retains a visible years suffix while the underlying value remains numeric.
- Tip: Bill Amount, Tip Rate(%) and Number of Person use the same card dimensions and vertical label/value hierarchy.
- Discount, Salary and SIP fields also use the shared card system; Discount output rows appear only after equals is committed.

## Behavior corrections
- Shared keypad equals commits calculation, hides the keypad and reveals the result area. Reopening any editable field hides stale results and reopens the keypad.
- GST and Percentage now reject blank required fields rather than producing a misleading zero result.
- Discount now validates required values and finite output before presenting results.
- Existing GST inclusive/exclusive and same-state/different-state tax split logic is retained.
- Existing Saving, Tip, Salary and SIP calculation engines are retained; UI changes do not change their formula conventions.

## Build and validation
- Release: `1.98.88-v98.74`
- Android versionCode: `1098500`
- Fresh `www/` Android web bundle generated from source.
- Root and generated web assets byte-synchronized.
- Regression suite: 50/50 passed.
- JavaScript syntax checks passed.
- Both workflow YAML files parsed successfully.
- ZIP integrity verified after packaging.

## Validation boundary
No Android APK build or physical-device screenshot/touch test was executed in this environment. The release is source/build-bundle verified, not certified device-level pixel-identical or lag-free.
