# SA Calculator v98.70 — Reference Tools Restored

SA Calculator is a mobile-first calculator app with standard/scientific calculation, history, favorites, themes, localization, and focused utilities. All twelve reference calculator tools are restored: GST, Loan/EMI, Saving, Salary, Tip, SIP, Currency Converter, Discount, Percentage, Unit Converter, Age Calculator and BMI.

## Release identity
- App version: `1.98.84-v98.70`
- Android versionCode: `1098100`
- Active screens: Calculator, Date, Fuel Cost, Fuel Efficiency, Grade Average, Number Base, Unit Price, World Time, Tools, Favorites and Settings.
- Android workflow: `Android-Workflow-v98.70.yml`

## Verify locally
```sh
npm test
npm run build:web
```

## Android APK
Copy `Android-Workflow-v98.70.yml` to `.github/workflows/main.yml`, commit the complete project, and run the workflow in GitHub Actions. It generates/synchronizes the Capacitor Android project and assembles a debug APK. The source archive does not include a prebuilt APK.

## Validation boundary
The v98.70 release passes 38 automated regression tests, JavaScript syntax checks, CSS parsing, workflow YAML parsing, removal-scope checks and Android web-bundle synchronization. Android APK compilation, installation, physical-device layout, frame rate and memory pressure still require GitHub Actions and target-device testing. Automated tests do not prove zero lag or zero bugs on every Android device.


## v98.74 card and currency update

All numeric input cards now share the Loan reference card geometry. Currency From/To cards use the same dimensions and typography; currency result output is read-only, searchable currency selection dismisses the keypad while open, and the tall keypad action swaps the selected pair. See `CARD-CURRENCY-MICRO-AUDIT-v98.74.md`.


## v98.74 GST / Saving / Tip / Percentage reference correction

Rebuilt the field-card layout from the supplied screenshots: each editable field now uses the Loan reference geometry (88px standard / 82px compact, 50px icon tile, 22px radius, 2px border, vertical label/value stack). GST mode and supply controls remain outside the cards, quick rates stay within the rate card, Percentage is reduced to the two-field percentage-of screen shown in the reference, and result panels appear after the shared keypad equals action dismisses the keypad. Saving, Tip, Salary and SIP use the same card hierarchy.
