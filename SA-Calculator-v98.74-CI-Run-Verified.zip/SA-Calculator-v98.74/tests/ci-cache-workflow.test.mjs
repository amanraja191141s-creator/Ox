import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const workflow = fs.readFileSync('.github/workflows/main.yml', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

test('CI caches npm downloads without requiring a missing lockfile', () => {
  assert.equal(fs.existsSync('package-lock.json'), false,
    'this release intentionally uses npm install without a committed lockfile');
  assert.ok(workflow.includes('uses: actions/cache@v4'));
  assert.ok(workflow.includes('path: ~/.npm'));
  assert.ok(workflow.includes("hashFiles('**/package.json')"));
  assert.ok(workflow.includes('npm-${{ runner.os }}-node22-'));
  assert.ok(workflow.includes('package-manager-cache: false'));
});

test('npm cache is restored before dependency installation', () => {
  assert.ok(workflow.indexOf('name: Cache npm downloads') < workflow.indexOf('name: Install npm dependencies'));
  assert.ok(pkg.dependencies['@capacitor/core']);
  assert.ok(pkg.dependencies['@capacitor/android']);
});

test('v98.74 release identity is synchronized across package, runtime, HTML, PWA and service worker', () => {
  const expected = '1.98.88-v98.74';
  assert.equal(pkg.version, expected);
  assert.equal(pkg.androidVersionCode, 1098500);
  assert.ok(fs.readFileSync('index.html', 'utf8').includes(expected));
  assert.ok(fs.readFileSync('assets/js/app.js', 'utf8').includes(`const APP_VERSION = '${expected}'`));
  assert.equal(JSON.parse(fs.readFileSync('manifest.webmanifest', 'utf8')).version, expected);
  assert.match(fs.readFileSync('service-worker.js', 'utf8'), /sa-calculator-v98-74-finance-reference-v9874/);
});

test('Android workflow validates real v98.74 test paths and release code', () => {
  assert.ok(workflow.includes('if(p.androidVersionCode!==1098500)'));
  assert.ok(workflow.includes('tests/tool-restoration-regression-v9870.test.mjs'));
  assert.ok(workflow.includes("tests/tool-reference-video-regression-v9873.test.mjs"));
  assert.ok(workflow.includes('tests/tool-reference-finance-regression-v9874.test.mjs'));
  assert.ok(workflow.includes('tests/tool-reference-video-regression-v9873.test.mjs'));
  assert.ok(workflow.includes('tests/tool-reference-finance-regression-v9874.test.mjs'));
  assert.ok(pkg.scripts['test:release'].includes('tests/tool-reference-video-regression-v9873.test.mjs'));
  assert.ok(workflow.includes('tests/tool-reference-finance-regression-v9874.test.mjs'));
  assert.ok(pkg.scripts['test:release'].includes('tests/tool-reference-finance-regression-v9874.test.mjs'));
  assert.ok(!workflow.includes('tests/tool-removal-regression-v9869.test.mjs'));
  for (const file of ['tests/tool-restoration-regression-v9870.test.mjs', 'assets/js/app.js', 'assets/css/app.css', 'assets/css/tool-reference-ui.css']) {
    assert.equal(fs.existsSync(file), true, `required workflow file missing: ${file}`);
  }
});
